package com.test;
import org.junit.Jupiter.api.Test;
import static org.junit.Jupiter.api.Assertions.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;


public class FileSerializeTest{
    private final File saveDir;
    private final File saveFile;
    List<Task> tasks = new ArrayList<>();

    WriteAndReadFile testSerializer = new WriteAndReadFile();
    @TempDir
    Path tempDir;
    @Test
    public void testFileSerialization()
    {
        Path targetPath =  tempDir.resolve("user_data.ser");
        File targetFile = targetPath.toFile();
        Task task = new Task("Тестовая задача");
        tasks.add(task);
        testSerializer.save(tasks);
        Task deserializedTask = testSerializer.load();
        assertTrue(targetFile.exists(), "файл должен быть создан");
        assertTrue(targetFile.length()>0, "Файл не должен быть пустым");
        assertNotNull(deserializedTask, "Десериализованный объект не должен быть null");
        assertEquals(deserializedTask.getTitle().equals("Тестовая задача"));
    }
}
